/*
INSTRUCTIONS:
In p5, the challenge is to create a particle system. Every time the user clicks the mouse, a new particle should appear at their position, and start moving in a random direction. The particles should bounce off all the walls. In my example, the particles fall downward using gravity, but this is OPTIONAL.

Each particle should get smaller over time, and once it shrinks small enough, it should be removed from the array (so the computer doesn’t slow down too much).

The main topics that I’m looking for in this problem are building classes, instantiating classes as objects, using arrays & for-loops, and bouncing logic.
*/

function setup() {
  
}

function draw() {
  
}