/*
INSTRUCTIONS:
In AR, the challenge is to create a butterfly catching game. I chose to use a net catching a butterfly, but you can use any theme that you’d like.

There should be a number of butterflies on the screen, moving randomly with Perlin noise. The player uses a Hiro AR marker to control a net/object. When the player gets close to a butterfly, that specific butterfly disappears. The butterflies are drawn using p5. When a butterfly hits any edge of the screen, it wraps-around to the other side.

The main topics that I’m looking for in this problem are building classes, using Perlin noise, using AR markers, loading & showing images in p5, and changing behavior using the distance function.
*/

// create a variable to hold our world object
var world;
var markerHiro;

function setup() {
  // create our world (this also creates a p5 canvas for us)
  world = new World('ARScene');

  // grab a reference to our two markers that we set up on the HTML side (connect to it using its 'id')
  markerHiro = world.getMarker('hiro');
  
  imageMode(CENTER);
}


function draw() {
  // erase the background
  world.clearDrawingCanvas();
}