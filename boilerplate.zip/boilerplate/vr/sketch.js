/*
INSTRUCTIONS:
In VR, the challenge is to build a very simple game where the player collects objects in VR. I chose to make my objects look like coins using cylinders, but you can use any object-primitive that you’d like. You should also practice putting an OBJ file into your VR world!

The objects should appear around the player in the VR world, and spin in place. When the user clicks on an object, a sound should play and the object should disappear from the world. I chose to include a spaceship spinning in place, but you can choose any 3D object to import, and you can move or spin it however you like. I would recommend starting your search for an object here, because these objects tend to work well with A-Frame.

The main topics I’m looking for here are using arrays/objects, adding many objects to the VR world, importing and displaying .obj files, using methods on A-Frame objects, and adding clickFunctions.
*/

// variable to hold a reference to our A-Frame world
var world;

function setup() {
	// no canvas needed
	noCanvas();
	world = new World('VRScene');
}

function draw() {

}